from PIL import Image

def lambda_handler(event, context):
    return {
        "statusCode": 200,
        "body": "Pillow is working!"
    }